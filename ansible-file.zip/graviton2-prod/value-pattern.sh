#!/bin/bash
echo "secrets: " >> ./helm_charts/$3/$1-$2/values.yaml
