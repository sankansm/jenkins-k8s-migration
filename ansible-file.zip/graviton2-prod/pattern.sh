#!/bin/bash
echo "secrets: " >> ./helm_charts/$3/$1-$2/values.yaml
for i in `cat ./secrets/$3/$1/$2/secret | cut -d "{" -f2 | cut -d "}" -f1 | tr "," "\n" | sed 's/ //g'`
do 
echo "  $i" | sed 's/:/: /g' | sed 's/\"//g' >> ./helm_charts/$3/$1-$2/values.yaml
done
